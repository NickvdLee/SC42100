#README
This repository contains the codebase for the assignments of the course SC42100 2019-2020.

Written by:
Pim de Bruin
Nick van der Lee 

28/05/2020
